module.exports = {

    'secret': '$2a$10$1z8IBoPXQ/vK1Bo/qwiIku',
};