<!-- works -->
<section id="<?php echo $id; ?>" class="works section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title">
                    <h2><?php echo $contents['title']; ?></h2>
                    <p><?php echo $contents['description']; ?></p>
                </div>

                <div class="works-gallery">
                    <div id="gallery-container" >
                        <?php foreach($contents['works'] as $ii=>$contents): ?>
                            <div class="block">
                                <img alt="" src="<?php echo $contents['portfolio-image']; ?>"/>
                                <div class="item-musk">
                                    <div class="item-caption">
                                        <h4><?php echo $contents['portfolio-title']; ?></h4>
                                        <p><?php echo $contents['portfolio-description'] ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('#gallery-container').justifiedGallery({
                rowHeight : 250,
                lastRow : 'nojustify',
                margins : 6,
                captions: false,
                sizeRangeSuffixes: {
                    100 : '_t', // used with images which are less than 100px on the longest side
                    240 : '_m', // used with images which are between 100px and 240px on the longest side
                    320 : '_n', // ...
                    500 : '',
                    640 : '_z',
                    1024 : '_b' // used which images that are more than 640px on the longest side
                }
            });
    });
    </script>
</section>
