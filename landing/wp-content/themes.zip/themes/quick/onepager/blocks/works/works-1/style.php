#<?php echo $id ?> {
	background: <?php echo $styles['background-color'] ;?>;
}
#<?php echo $id ?> .title h2 {
	color:<?php echo $styles['title-color']; ?>;
}
#<?php echo $id ?> .title h2:before {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .title h2:after {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}