<?php

return array(
  'slug'    => 'quick-works',
  'groups'    => array('works'),

  'contents' => array(
    array(
      'name'=>'title',
      'value'=>'Latest Works',
    ),
    array(
      'name'=>'description',
      'type'=>'textarea',
      'value' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex',
    ),

    array(
      'name'=>'works',
      'type'=>'repeater',
      'fields' => array(
        array(
          array('name'=>'portfolio-title', 'value' => 'Lorem ipsum dolor sit amet.'),
          array('name'=>'portfolio-description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
          array(
      'name'=>'portfolio-image',
      'type' => 'image',
    )
        ),
      )
    )
  ),

  'settings' => array(
      array(
        'name'=>'hover-color',
        'type'=>'colorpicker',
        'label'=>'Hover Color',
        'value' => '#8ec64e'
      ),
  ),

  'styles' => array(
    array(
      'label'=>'Background Color',
      'name'=>'background-color',
      'type' => 'colorpicker',
    ),
    array(
      'label'=>'Title Color',
      'name'=>'title-color',
      'type' => 'colorpicker',
    ),
    array(
      'label'=>'Paragraph Color',
      'name'=>'paragraph-color',
      'type' => 'colorpicker',
    ),
    
  ),
  'assets' => function( $path ){
    onepager()->asset()->style( 'quick-works-1', $path . '/style.css' );
  }

  
);
