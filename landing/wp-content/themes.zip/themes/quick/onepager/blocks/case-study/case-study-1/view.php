 <!-- testimonial -->
    <section id="<?php echo $id; ?>" class="case-study section">
        <div class="container">
            <div class="row">
                <div class="title">
                    <h2><?php echo $contents['title']; ?></h2>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 ">
                    <!-- Set up your HTML -->
                    <div class="row">
                        <div id="case-study-slider" class="owl-carousel">
                            <?php foreach ($contents['sliders'] as $ii => $slider):?>
                                <div>
                                    <div class="block">
                                        <div class="col-md-4 col-sm-5 col-xs-12">
                                            <img class="img-responsive" src="<?php echo $slider['banner']; ?>" alt="...">
                                        </div>
                                        <div class="col-md-8 col-sm-7 col-xs-12">
                                            <div class="caption">
                                                <h3>
                                                    <?php echo $slider['title']; ?>
                                                </h3>
                                                <p>
                                                    <?php echo $slider['description']; ?>
                                                </p>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach ?>
                        </div>
                    
                    </div> 
                </div>
            </div>
        </div>
        <script>
        jQuery(function(){
            jQuery("#case-study-slider").owlCarousel({
                items:1,
                autoPlay:true,
                pagination:false,
                itemsDesktop : [1199,4],
                itemsDesktopSmall : [980,1],
                itemsTablet: [768,1],
                itemsMobile : [479,1],
            });
        });


        </script>
    </section>
    <!-- // testimonial -->
