<?php

return array(
  'slug'    => 'quick-case-study-1',
  'groups'    => array('case-study'),

  'contents' => array(
    array(
      'name'=>'title',
      'value'=>'Case Study',
    ),


    array(
      'name'=>'sliders',
      'type'=>'repeater',
      'fields' => array(
        array(
          array('name'=>'title','value'=>'GRAPHICS & PRINT WORK'),
          array('name'=>'banner', 'type'=>'media'),
          array('name'=>'description','type'=> 'textarea', 'value' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquipex ea commodo consequat.'),
        ),
        
      )
    )
  ),

  'settings' => array(
      array(
        'name'=>'background-image',
        'type'=>'image',
        'label'=>'Background Image',
      ),
  ),

  'styles' => array(
  ),
  'assets' => function($url){
    Onepager::addStyle('quick-case-study-1', $url."/style.css");
  }
);
