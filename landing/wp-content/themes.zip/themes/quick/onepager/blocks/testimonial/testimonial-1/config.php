<?php

return array(
  'slug'    => 'quick-testimonial',
  'groups'    => array('testimonials'),

  'contents' => array(
    array(
      'name'=>'title',
      'value'=>'MY WORKING PROCESS',
    ),


    array(
      'name'=>'items',
      'type'=>'repeater',
      'fields' => array(
        array(
          array('name'=>'testimonial-description','type'=> 'textarea', 'value' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquipex ea commodo consequat.'),
          array('name'=>'description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
          array('name'=>'name', 'type'=>'text', 'value'=> 'Adam Smith'),
          array('name'=>'signature', 'type'=>'media',),
        ),
        
      )
    )
  ),

  'settings' => array(
      array(
        'name'=>'background-image',
        'type'=>'image',
        'label'=>'Background Image',
      ),
  ),

  'styles' => array(
  ),
  'assets' => function($url){
    Onepager::addStyle('quick-testimonial-1', $url."/style.css");

  }
);
