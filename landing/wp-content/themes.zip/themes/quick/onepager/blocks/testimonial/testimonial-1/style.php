#<?php echo $id ?> {
	background:url('<?php echo $settings['background-image'] ;?>');
	background-size:cover;
}
#<?php echo $id ?> .title h2:before {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .title h2:after {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}