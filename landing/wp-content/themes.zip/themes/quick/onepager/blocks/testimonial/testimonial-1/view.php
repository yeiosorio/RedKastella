 <!-- testimonial -->
    <section id="<?php echo $id; ?>" class="testimonial">
        <div class="dark-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="title">
                    <h2><?php echo $contents['title']; ?></h2>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 ">
                    <!-- Set up your HTML -->
                    <div class="testimonial-slider">
                        <?php foreach($contents['items'] as $ii=>$contents): ?>
                            <div>
                                <p>
                                    <?php echo $contents['testimonial-description'] ?>
                                </p>
                                <span><?php echo $contents['name']; ?></span>
                                <div class="signature">
                                    <img src="<?php echo $contents['signature'] ?>" alt="">
                                </div>
                          </div>
                        <?php endforeach; ?> 
                      
                      
                    </div>

                        
                </div>
            </div>
        </div>
        <script>
        jQuery(function(){
            jQuery(".testimonial-slider").owlCarousel({
                items:1,
                autoPlay:true,
                itemsDesktop : [1199,4],
                itemsDesktopSmall : [980,1],
                itemsTablet: [768,1],
                itemsMobile : [479,1],
            });
        });


        </script>
    </section>
    <!-- // testimonial -->
