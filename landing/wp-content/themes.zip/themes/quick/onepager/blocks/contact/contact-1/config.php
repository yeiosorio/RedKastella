<?php 

return array(
	'slug'      => 'quick-contact', // Must be unique
  	'groups'    => array('contacts'), // Blocks group for filter

  	'contents' => array(
	  	array(
	      'name'=>'title', 
	      'value' => 'Get In Touch'
	    ),
	    array(
	    	'name'=>'subtitle',
	    	'value'	=> 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos, voluptates.',
	    	'type'	=> 'textarea',
	    ),
	    array(
	      'name'=>'contact_form',
	      'type'=>'textarea', 
	      'value'=> '[contact-form-7 id="4" title="Contact form 1"]'
	    ),
	    array(
	    	'name' => 'address-title',
	    	'type'	=> 'text',
	    	'value'	=> 'Our HUB',
	    ),
	    array(
	    	'name'	=> 'address',
	    	'value'	=> 	'Dhanmondi 32,Dhaka, Bangladesh',
	    	'type'	=>	'textarea'
	    ),
	    
	    array(
	      'name'=>'email-address',
	      'type'=>'textarea', 
	      'value'=> 'themefisher@gmail.com'
	    ),
	    
	    array(
	      'name'=>'phone-number',
	      'type'=>'textarea', 
	      'value'=> '[+00 93 213 123 123]'
	    ),

	),


	'styles' => array(
		array(
			'name' => 'background-color',
			'label'	=> 'Background Color',
			'type' => 'colorpicker',
		),
		array(
			'name' => 'title-color',
			'label'	=> 'Title Color',
			'type' => 'colorpicker',
		),
		array(
			'name' => 'subtitle-color',
			'label'	=> 'SubTitle Color',
			'type' => 'colorpicker',
		),
		array(
	      'label'=>'Button Color',
	      'name'=>'button-color',
	      'type' => 'colorpicker',
	    ),
	),

	  // Settings - $settings available on view file to access the option
  'settings' => array(    
      
  ),
  'assets' => function( $path ){
    onepager()->asset()->style( 'quick-contact-1', $path . '/style.css' );
  }

);
