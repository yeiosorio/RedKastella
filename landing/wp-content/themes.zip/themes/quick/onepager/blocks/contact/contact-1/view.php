<!-- contact -->
<div id="<?php echo $id; ?>" class="contact section">
    <div class="container">
        <div class="row">
            <div class="title">
                <h2><?php echo $contents['title']; ?></h2>
                <p><?php echo $contents['subtitle']; ?></p>
            </div>
            <div class="col-xs-12 col-sm-8 col-md-8">
                <div  class="contact-form">
                    <?php echo do_shortcode($contents['contact_form']) ?>
                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
                <div class="contact-address">
                    <h4><?php echo $contents['address-title']; ?></h4>
                    <ul>
                        <li class="address"><?php echo $contents['address']; ?></li>

                        <li class="phone"><?php echo $contents['phone-number'] ?></li>
                        <li class="email"><?php echo $contents['email-address'] ?></li>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</div>







