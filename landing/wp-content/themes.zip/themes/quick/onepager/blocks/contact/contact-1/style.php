#<?php echo $id ?> {
	background-color: <?php echo $styles['background-color'] ?>;
}
#<?php echo $id ?> .title h2 {
	color : <?php echo $styles['title-color'] ?>
}
#<?php echo $id ?> .contact-form input[type=submit] {
	background: <?php echo $styles['button-color'] ;?>;
	border: 2px solid <?php echo $styles['button-color'] ;?>;
	font-size: 16px;
	font-weight: 500;
	padding: 11px 70px 13px;
	color:#fff;
}

#<?php echo $id ?> .contact-address h4 {
	color: <?php echo $styles['subtitle-color'] ?>
}

#<?php echo $id ?> .title h2:before {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .title h2:after {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .contact-address ul li.phone {
	color:<?php echo Onepager::getoption('color')['primary'] ?> ;
}

#<?php echo $id ?> .contact-form input[type=submit] {
	background:<?php echo Onepager::getoption('color')['primary'] ?> ;
	border:<?php echo Onepager::getoption('color')['primary'] ?> ;

}
