<?php

return array(
  'slug'    => 'quick-experience',
  'groups'    => array('experience-1'),

  'contents' => array(
    array(
      'name'=>'work_title',
      'type'=>'text',
      'value' => 'WORK EXPERIENCE'
    ),
    array(
      'name'=>'items',
      'type'=>'repeater',
      'fields' => array(
        array(
          array('name'=>'job-title', 'type'=>"text", 'value' => 'Themefisher.inc'),
          array('name'=>'job-duration', 'type'=> 'text', 'value'=>'Oct 2013 - june 2014'),
          array('name'=>'job-description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
        ),
        array(
          array('name'=>'job-title','type'=>"text", 'value' => 'Themexpert'),
          array('name'=>'job-duration', 'type'=> 'text', 'value'=>'Oct 2013 - june 2014'),
          array('name'=>'job-description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
        ),
      ),
    ),
    array(
      'name'=>'experience_title',
      'type'=>'text',
      'value' => 'EDUCATION'
      
    ),
    array(
      'name'=>'education',
      'type'=>'repeater',
      'fields' => array(
        array(
          array('name'=>'education-title', 'type'=>"text", 'value' => 'Themefisher.inc'),
          array('name'=>'education-duration', 'type'=> 'text', 'value'=>'Oct 2013 - june 2014'),
          array('name'=>'education-description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
        ),
        array(
          array('name'=>'education-title','type'=>"text", 'value' => 'Themexpert'),
          array('name'=>'education-duration', 'type'=> 'text', 'value'=>'Oct 2013 - june 2014'),
          array('name'=>'education-description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
        ),
      ),
    ),
  ),






  'settings' => array(

  ),

  'styles' => array(
    array(
      'name'=>'Background',
      'type'=>'media',
      
    ),
  ),

  'assets' => function( $path ){
    onepager()->asset()->style( 'quick-experience-1', $path . '/style.css' );
  }
);
