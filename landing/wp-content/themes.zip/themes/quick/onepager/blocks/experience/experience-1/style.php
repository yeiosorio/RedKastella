#<?php echo $id ?> {
	background:url('<?php echo $styles['Background'] ?>');
	background-size:cover;
}
	
