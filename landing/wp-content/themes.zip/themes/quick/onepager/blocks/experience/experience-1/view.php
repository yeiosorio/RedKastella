<!-- experience -->
        <div id="<?php echo $id; ?>" class="experience section">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 ">
                        <div class="exp-block">
                            <h3> <i class="icon-globe"></i><?php echo $contents['work_title']; ?></h3>
                            <ul class="list-none">
                                <?php foreach($contents['items'] as $ii=>$features): ?>
                                    <li>
                                        <h4><?php echo $features['job-title'] ?></h4>
                                        <span><?php echo $features['job-duration'] ?></span>
                                        <p><?php echo $features['job-description'] ?></p>

                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6">
                        <div class="exp-block">
                            <h3> <i class="icon-book-open"></i><?php echo $contents['experience_title']; ?></h3>
                            <ul class="list-none">
                                <?php foreach($contents['education'] as $ii=>$features): ?>
                                    <li>
                                        <h4><?php echo $features['education-title'] ?></h4>
                                        <span><?php echo $features['education-duration'] ?></span>
                                        <p><?php echo $features['education-description'] ?></p>

                                    </li>
                                <?php endforeach; ?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
