#<?php echo $id ?> {
	background: <?php echo $styles['background-color'] ?>;
}
#<?php echo $id  ?> .social-icons a:hover {
	background:<?php echo $styles['icon_hover'] ?>;
}
#<?php echo $id ?>  .copyright {
	color: <?php echo $styles['paragraph-color'] ?> ;
}
#<?php echo $id ?>  .social-icons a {
	color: <?php echo $styles['icon_color'] ?>;
}
#<?php echo $id ?> .copyright a {
	color:<?php echo Onepager::getoption('color')['primary'] ?> ;
}

#<?php echo $id ?> .social-icons a:hover {
	background:<?php echo Onepager::getoption('color')['primary'] ?> ;
}