<?php

return array(
  
  'slug'      => 'Quick-footer', // Must be unique and singular
  'groups'    => array('footers'), // Blocks group for filter and plural

  // Fields - $contents available on view file to access the option
  'contents' => array(
    array(
      'name'=>'copyright-text', 
      'value' => 'Copyright &copy; 2015 <a href="http://www.themefisher.com">Themefisher</a> , All Rights Reserved . Powered By <a href="http://www.getonepager.com">Onepager</a>'
    ),
    array('name'=> 'social', 'label' => 'Social Links', 'value' => array('http://facebook.com/themefisher', 'http://twitter.com/themefisher', 'http://linkedin.com/themefisher', 'http://dribbble.com/themefisher') ),
    
  ),

  
  // Settings - $settings available on view file to access the option
  'settings' => array(    
      
  ),

  // Fields - $styles available on view file to access the option
  'styles' => array(
    array(
        'name'=>'background-color',
        'type'=>'colorpicker',
        'label'=>'Background-color',
      ),
    array(
        'name'=>'icon_color',
        'type'=>'colorpicker',
        'label'=>'Icon Color',
      ),
    array(
        'name'=>'icon_hover',
        'type'=>'colorpicker',
        'label'=>'Icon Hover Color',
      ),
    array(
        'name'=>'paragraph-color',
        'type'=>'colorpicker',
        'label'=>'Paragraph Color',
      ),
  ),

  'assets' => function($url){
    Onepager::addStyle('quick-footer-1', $url."/style.css");

  }
  

);