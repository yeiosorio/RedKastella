<footer id="<?php echo $id; ?>" class="footer">
    <div class="conainer text-center">
        <div class="social-icons clearfix">
            <?php foreach ( $contents['social'] as $social ): ?>
                <a class="icon" href="<?php echo $social ?>" target="_blank">
                </a>
            <?php endforeach; ?>            
        </div> 

        <div class="copyright">
            <p><?php echo $contents['copyright-text']; ?></p>
        </div>
    </div>
</footer>