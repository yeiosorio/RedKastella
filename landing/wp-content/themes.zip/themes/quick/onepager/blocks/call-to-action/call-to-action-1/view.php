<?php
    function is_video($src)
    {
        $ext = substr($src, -3);
        return ( $ext == 'mp4' OR $ext == 'ogv' OR $ext == 'webm') ? true : false;
    }
?>
 <!-- Call To Action -->
    <section id="<?php echo $id; ?>" class="video-call-to-action">
        <div class="video-bg">
            <?php if(is_video($contents['media'])): ?>
                <video autoplay loop class="fillWidth">
                    <source src="<?php echo $contents['media']?>" type="video/mp4" />Your browser does not support the video tag. I suggest you upgrade your browser.
                </video>
            <?php else :?>
                <?php if($contents['media']):?>
                    <img class="" src="<?php echo $contents['media']?>" alt="<?php echo $contents['title']?>">
                <?php endif; ?>
            <?php endif;?>
        </div>
            
        
        <div class="dark-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 ">
                    <div class="video-text-block text-center">
                        <h2><?php echo $contents['title'] ?></h2>
                        <p><?php echo $contents['description'] ?></p>
                        <a href="" class="btn btn-buy">
                            <?php echo $contents['button'] ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- // video call to action -->
