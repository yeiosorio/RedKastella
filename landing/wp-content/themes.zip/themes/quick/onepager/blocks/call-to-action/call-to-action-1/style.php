#<?php echo $id ?> .btn-buy{
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
	border:1px solid transparent;
}
#<?php echo $id ?> .btn-buy:hover {
	background:#fff;
	border:1px solid <?php echo Onepager::getoption('color')['primary'] ?>;
	color:<?php echo Onepager::getoption('color')['primary'] ?>;
}
