<?php

return array(
  'slug'    => 'quick-call-to-action-1',
  'groups'    => array('call-to-action'),

  'contents' => array(
    array(
      'name'=>'media',
      'label'=>'Media',
      'type' => 'media',
    ),
    array(
      'name'=>'title',
      'value'=>'Video for better visualization',
    ),
    array(
      'name'=>'description',
      'value'=>'Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.',
    ),
    array(
      'name'=>'button',
      'label'=>'Button Text',
      'value'=>'Buy Now',
    ),

  ),

  'settings' => array(
      
  ),

  'styles' => array(
  ),
  'assets' => function($url){
    Onepager::addStyle('quick-call-to-action-1', $url."/style.css");

  }
);
