<!-- about -->
<section id="<?php echo $id ?>" class="about-2">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="title">
                    <h2><?php echo $contents['title']; ?></h2>
                </div>
                <p>
                    <?php echo $contents['description']; ?>
                </p>
                <div class="button">
                    <a href="#" class="btn btn-buy">Buy Now</a>
                </div>
                <div class="separator clearfix">
                    <span></span>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- // about -->




