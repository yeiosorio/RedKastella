<?php

return array(
  'slug'    => 'quick-about-1',
  'groups'    => array('abouts'),

  'contents' => array(
    array(
      'name'=>'title',
      'value'=>'MY NAME IS ANGELISA EASTER'
    ),
    array(
      'name'=>'subtitle',
      'value'=>'Angelisa Easter Lisa, 28 years young, born and grew up in Australia, Grand Line. Highly motivated creative designer with international client portfolio.'
    ),
    array(
      'name'=>'description',
      'type'=>'textarea',
      'value' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquipex ea commodo consequat.'
    ),

    array(
      'name'=>'author-image',
      'type' => 'image',

    ),
 







  ),




  'settings' => array(


  ),

  'styles' => array(
    array(
      'label'=>'Background Color',
      'name'=>'background-color',
      'type' => 'colorpicker',
    ),
    array(
      'label'=>'Title Color',
      'name'=>'title-color',
      'type' => 'colorpicker',
    ),
    array(
      'label'=>'Paragraph Color',
      'name'=>'paragraph-color',
      'type' => 'colorpicker',
    ),
    array(
      'name'=>'icon_color',
      'type'=>'colorpicker',
      'label'=>'Icon Color',
      'value' => '@color.primary'
    ),
  ),

  'assets' => function($url){
    Onepager::addStyle('quick-about-1', $url."/style.css");

  }
  
);
