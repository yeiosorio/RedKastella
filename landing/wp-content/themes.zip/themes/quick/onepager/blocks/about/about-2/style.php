#<?php echo $id ?>.about {
	background: <?php echo $styles['background-color'] ;?>;
}
#<?php echo $id ?> .about-intro h3 {
	color:<?php echo $styles['title-color']; ?>;
}
#<?php echo $id ?> .about-intro h5 ,#<?php echo $id ?> .about-intro p {
	color:<?php echo $styles['paragraph-color']; ?>;
}
#<?php echo $id ?> .button .btn-buy {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
	padding: 10px 35px;
}
#<?php echo $id ?> .btn-buy {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
	border:1px solid transparent;
}
#<?php echo $id ?> .btn-buy:hover {
	border: 1px solid <?php echo Onepager::getoption('color')['primary'] ?> ;
	color:#fff;
}
#<?php echo $id ?> .title h2:before {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .title h2:after {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .btn-buy:hover {
	background:#fff;
	border:1px solid <?php echo Onepager::getoption('color')['primary'] ?>;
	color:<?php echo Onepager::getoption('color')['primary'] ?>;
}
.service-block-2:hover .icon-holder i {
 	color:   <?php echo Onepager::getoption('color')['primary'] ?>;
}
