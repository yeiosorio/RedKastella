<?php

return array(
  'slug'    => 'quick-about-2',
  'groups'    => array('abouts'),

  'contents' => array(
    array(
      'name'=>'title',
      'value'=>'MY NAME IS ANGELISA EASTER'
    ),
    array(
      'name'=>'description',
      'type'=>'textarea',
      'value' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquipex ea commodo consequat.'
    ),

    array(
      'name'=>'author-image',
      'type' => 'image',

    ),
 







  ),




  'settings' => array(


  ),

  'styles' => array(
    array(
      'label'=>'Background Color',
      'name'=>'background-color',
      'type' => 'colorpicker',
    ),
    array(
      'label'=>'Title Color',
      'name'=>'title-color',
      'type' => 'colorpicker',
    ),
    array(
      'label'=>'Paragraph Color',
      'name'=>'paragraph-color',
      'type' => 'colorpicker',
    ),
  ),
  'assets' => function($url){
    Onepager::addStyle('quick-about-2', $url."/style.css");

  }

  
);
