#<?php echo $id ?>.about {
	background: <?php echo $styles['background-color'] ;?>;
}
#<?php echo $id ?> .about-intro h3 {
	color:<?php echo $styles['title-color']; ?>;
}
#<?php echo $id ?> .about-intro h5 ,#<?php echo $id ?> .about-intro p {
	color:<?php echo $styles['paragraph-color']; ?>;
}
#<?php echo $id ?> .about-intro .divider {
	background:<?php echo Onepager::getoption('color')['primary'] ?> ;
	
}
#<?php echo $id ?> .title h2:before {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .title h2:after {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
