<!-- about -->
<section id="<?php echo $id ?>" class="about">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-5">
                <div class="author-thumb text-center">
                    <img class="slideInUp wow" src="<?php echo $contents['author-image']; ?>" alt="">
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-7 wow fadeInRight">
                <div class="about-intro">
                    <div class="title">
                        <h2><?php echo $contents['title']; ?></h2>
                        <p><?php echo $contents['subtitle']; ?></p>
                    </div>
                    <span class="divider"></span>
                    <p><?php echo $contents['description']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- // about -->




