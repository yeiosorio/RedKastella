#<?php echo $id ?>.service  {
	background: <?php echo $styles['background-color']?>;
}

#<?php echo $id ?> .service-inner i {
	color: <?php echo $styles['icon_color']?>;
}

#<?php echo $id ?> .service-inner .icon-holder {
	background:<?php echo $styles['background-color']?>;
}
#<?php echo $id ?> .title h2 {
	color: <?php echo $styles['title-color'] ?> ;
}
#<?php echo $id ?> .service-block .service-inner {
	color: <?php echo $styles['title-color'] ?> ;
}

#<?php echo $id ?> .title h2:before {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .title h2:after {
	background: <?php echo Onepager::getoption('color')['primary'] ?> ;
}
#<?php echo $id ?> .service-inner i {
	color: <?php echo Onepager::getoption('color')['primary'] ?>;	
}
#<?php echo $id ?> .service-block .service-inner:hover {
	border-color: <?php echo Onepager::getoption('color')['primary'] ?>;
}