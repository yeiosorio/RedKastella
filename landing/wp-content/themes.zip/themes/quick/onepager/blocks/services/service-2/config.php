<?php

return array(
  'slug'    => 'quick-service-2',
  'groups'    => array('services'),

  'contents' => array(
    array(
      'name'=>'title',
      'value'=>'MY WORKING PROCESS',
    ),
    array(
      'name'=>'description',
      'type'=>'textarea',
      'value' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex',
    ),

    array(
      'name'=>'items',
      'type'=>'repeater',
      'fields' => array(
        array(
          array('name'=>'title', 'value' => 'Design'),
          array('name'=>'description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
          array('name'=>'media', 'type'=>'media', 'value'=> 'icon-telescope'),
        ),
        array(
          array('name'=>'title', 'value' => 'Development'),
          array('name'=>'description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
          array('name'=>'media', 'type'=>'media', 'value'=> 'icon-mobile'),
        ),
        array(
          array('name'=>'title', 'value' => 'Branding'),
          array('name'=>'description', 'type'=> 'textarea', 'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, in?'),
          array('name'=>'media', 'type'=>'media', 'value'=> 'icon-pencil'),
        ),
      )
    )
  ),

  'settings' => array(
      
  ),

  'styles' => array(
    array(
      'name'=>'background-color',
      'type'=>'colorpicker',
      'label'=>'Background Color',
    ),
    array(
      'name'=>'hover-color',
      'type'=>'colorpicker',
      'label'=>'Hover Color',
      'value' => '#8ec64e'
    ),
    array(
      'name'=>'icon_color',
      'type'=>'colorpicker',
      'label'=>'Icon Color',
      'value' => '@color.primary'
    ),
    array(
      'name'=>'title-color',
      'type'=>'colorpicker',
      'label'=>'Title Color',
    ),
    

  ),
  'assets' => function($url){
    Onepager::addStyle('quick-service-2', $url."/style.css");

  }

  
);
