<!-- service -->
<div id="<?php echo $id; ?>" class="service section">
    <div class="container">
        <div class="row">
            <div class="title">
                <h2><?php echo $contents['title']; ?></h2>
                <p><?php echo $contents['description']; ?></p>
            </div>

            <?php foreach($contents['items'] as $ii=>$feature): ?>
                <div class="service-block col-xs-12 col-sm-6 col-md-4">
                    <div class="service-inner">
                        <div class="icon-holder">
                            <i class="<?php echo $feature['media'] ?>"></i>

                        </div>
                        <h4 class="heading"><?php echo $feature['title']?></h4>
                        <p class="description"><?php echo $feature['description']?></p>
                    </div>
                </div>
            <?php endforeach; ?> 
        

        </div>
    </div>
</div>