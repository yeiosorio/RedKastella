<!-- service -->
<div id="<?php echo $id; ?>" class="service-2 section">
    <div class="container">
        <div class="row">
            <?php foreach($contents['items'] as $ii=>$feature): ?>
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="service-block-2 text-center">
                        <div class="icon-holder">
                            <i class="<?php echo $feature['media'] ?>"></i>
                        </div>
                        <h4 class="heading"><?php echo $feature['title']?></h4>
                        <p class="description"><?php echo $feature['description']?>
                        </p>
                    </div>
                </div>
            <?php endforeach; ?> 
        

        </div>
    </div>
</div>
