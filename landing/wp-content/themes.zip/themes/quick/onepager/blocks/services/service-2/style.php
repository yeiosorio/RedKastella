#<?php echo $id ?>.service  {
	background: <?php echo $styles['background-color']?>;
}

#<?php echo $id ?> .service-inner i {
	color: <?php echo $styles['icon_color']?>;
}

#<?php echo $id ?> .service-inner .icon-holder {
	background:<?php echo $styles['background-color']?>;
}
#<?php echo $id ?> .title h2 {
	color: <?php echo $styles['title-color'] ?>
}
#<?php echo $id ?> .service-block .service-inner {
	color: <?php echo $styles['title-color'] ?>
}

#<?php echo $id ?> .service-block-2:hover .service-block-2 .icon-holder i {
	color:<?php echo Onepager::getoption('color')['primary'] ?> ;

}	