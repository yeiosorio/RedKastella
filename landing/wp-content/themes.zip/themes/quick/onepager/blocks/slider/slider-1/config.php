<?php

return array(

  'slug'      => 'quick-slider-1', // Must be unique
  'groups'    => array('headers'), // Blocks group for filter

  // Fields - $contents available on view file to access the option
  'contents' => array(
   array(
      'name'=>'revoslider',
      'type'=> 'text',
      'placeholder'=>'[rev_slider alias="slider"]'
    ),
  
    array('name'=>'menu','type'=>'menu'),
    


    


  ),

  // Settings - $settings available on view file to access the option
  'settings' => array(
   
  ),
  
  'styles' => array(


  ),

  'assets' => function( $path ){
    onepager()->asset()->style( 'header-1', $path . '/style.css' );
  }
);
