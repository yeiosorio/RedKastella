 <!-- 
        Slider start
        ==================== -->
<section id="<?php echo $id; ?>">
    <div class="block">
        <?php echo(do_shortcode($contents['revoslider']))  ?>
    </div>
</section>






