 <!-- 
        Header start
        ==================== -->
    <header id ="<?php echo $id; ?>"  class="dark-header navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo site_url(); ?>">
                    <img class="logo-1" src="<?php echo $contents['logo']; ?>" alt="">
                </a>
            </div>
            
           

            <nav class="collapse navbar-collapse navbar-right">
                <?php wp_nav_menu(array(
                        'menu' =>$contents['menu'] ,
                        'menu_class'=>'nav navbar-nav navbar-right',
                        'container' =>false,
                      'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                      'walker'            => new wp_bootstrap_navwalker()
                    )) ?>
            </nav><!-- /.navbar-collapse -->
        </div>
    </header>
    






