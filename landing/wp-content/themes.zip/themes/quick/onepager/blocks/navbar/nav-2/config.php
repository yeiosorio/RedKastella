<?php

return array(

  'slug'      => 'quick-nav-2', // Must be unique
  'groups'    => array('navbars'), // Blocks group for filter

  // Fields - $contents available on view file to access the option
  'contents' => array(
    array(
      'name'=>'logo',
      'type'=> 'image',
    ),
    array('name'=>'menu','type'=>'menu'),

    ),

  // Settings - $settings available on view file to access the option
  'settings' => array(
   
  ),
  
  'styles' => array(

  ),

  'assets' => function($url){
    Onepager::addStyle('quick-nav-2', $url."/style.css");

  }

);
