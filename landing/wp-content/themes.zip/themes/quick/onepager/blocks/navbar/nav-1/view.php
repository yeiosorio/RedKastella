 <!-- 
        Header start
        ==================== -->
        <div id="preloader" style="display: none;">
            <div class="preloader loading">
                <span class="slice"></span>
                <span class="slice"></span>
                <span class="slice"></span>
                <span class="slice"></span>
                <span class="slice"></span>
                <span class="slice"></span>
            </div>
        </div>
<header id="<?php echo $id; ?>" class="site-header navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <!-- Desktop Menu -->
            <button type="button" class="navbar-toggle mobile-menu" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>


              <div class="nav-toggle hidden-xs toggle-menu-bar">
                    <button class="toggle-btn">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>


            <a class="navbar-brand" href="<?php echo site_url(); ?>">
                <?php if($contents['logo']) :?>
                    <img class="img-responsive" src="<?php echo $contents['logo']?>" alt="<?php wp_title(); ?>">
                <?php else : ?>
                    <?php wp_title(); ?>
                <?php endif; ?>
            </a>
        </div>
        
        
        

        <nav class="collapse navbar-collapse navbar-right"  id="main-menu">
            <?php wp_nav_menu(array(
                    'menu' =>$contents['menu'] ,
                    'menu_class'=>'nav navbar-nav navbar-right main-menu',
                    'menu_id'=>'top-nav',
                    'container' =>false,

                    )) ?>
        </nav><!-- /.navbar-collapse -->
    </div>
</header>



















