jQuery(function(){


	/* ========================================================================= */
	/*  Init WOW js for css3 animation
	/* ========================================================================= */

	var wow = new WOW({
	    mobile: false // trigger animations on mobile devices (default is true)
	});
	wow.init();
	
    var windowHeight = jQuery(window).height();

    jQuery(".fullscreen").css("height", windowHeight);

    jQuery(window).scroll(function() {
    	if (jQuery(window).scrollTop() >= 85) {
    		jQuery(".site-header").addClass("fixed");
    	}else {
    		jQuery(".site-header").removeClass("fixed");
    	}
    });

    

     jQuery(".testimonial-slider").owlCarousel({
            items:1,
            autoPlay:true,
        });

    


    // menu toggle 
    jQuery(".toggle-btn").on("click", function() {
    	jQuery(this).toggleClass("active");
    	jQuery(".site-header").toggleClass("active");
    });
    
    
});



jQuery(window).load(function() {

    jQuery("#preloader").fadeOut("slow");
});



