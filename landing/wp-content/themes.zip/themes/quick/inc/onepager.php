<?php 

if(function_exists('onepager')){
	Onepager::disableCoreBlocks();
	// Onepager::disableCorePresets();
	Onepager::registerPresets('onepager/presets');

	Onepager::getOptionPanel()
	  ->tab( 'general', 'Generals' )
	  ->add(
	    array(
	      'name'   => 'layout',
	      'label'  => 'Layout',
	      'type'  => 'select',
	      'options' =>array(
	      	'boxed'=>'Boxed',
	      	'fluid'=>'Fluid'
	      	)
	    )
	  );



}


