<form method="get" action="<?php echo home_url(); ?>/" class="wt_search_form" role="search">
<div class="wt_search_wrap"><input type="search" size="15" placeholder="<?php _e('Enter Search keywords...','wt_front');?>" class="wt_search_field" name="s" value=""/>
<div class="wt_search_btn"><input type="submit" value="&#xf002;" class="wt_search_go" /></div>
</div>
</form>