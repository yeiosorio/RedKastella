/**
 * WhoaThemes Extend WPBakery Visual Composer Shortcodes
 *
 * WhoaThemes Admin Script
 *
 */

;(function ($, window, undefined) {
  'use strict';

	var doc = $(document),
		win = $(window);

	var wt_shortcode = wt_shortcode || {};
  
	wt_shortcode = {
		init: function() {
			
			// content here					
		}
	};
   
	doc.ready(function() {    
		wt_shortcode.init();
	});

})(jQuery, this);
