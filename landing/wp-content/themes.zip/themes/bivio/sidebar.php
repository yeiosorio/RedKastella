<div id="wt_sidebarInner">
	<?php if(isset($post)){wt_theme_generator('wt_sidebar',$post->ID);}else{wt_theme_generator('wt_sidebar');} ?>
</div>  <!-- End wt_sidebarInner -->

               